/**
 * 2. models/history.ts - 历史记录模型扩展
 */
// packages/core/src/models/history.ts
/**
 * 历史记录项接口
 * @description 定义优化历史记录的数据结构
 */
export interface HistoryItem {
    /**
     * 唯一标识符
     */
    id: string;

    /**
     * 创建时间戳
     */
    timestamp: number;

    /**
     * 原始提示词
     */
    originalPrompt: string;

    /**
     * 优化后的提示词
     */
    optimizedPrompt: string;

    /**
     * 优化理由（可选）
     */
    reasoning?: string;
    /**
     * 版本号（新增）
     */
    version: number;

    /**
     * 组ID，用于关联同一原始提示词的不同迭代版本（新增）
     */
    groupId: string;

    /**
     * 迭代方向（新增）
     */
    iterationDirection?: string;
    /**
     * 使用的模型ID（可选）
     */
    modelId?: string;

    /**
     * 标签列表（可选）
     */
    tags?: string[];

    /**
     * 是否收藏（可选）
     */
    favorite?: boolean;

    /**
     * 用户注释（可选，新增）
     */
    notes?: string;
}

/**
 * 历史记录筛选选项（新增）
 */
export interface HistoryFilter {
    /**
     * 开始时间戳
     */
    startTime?: number;

    /**
     * 结束时间戳
     */
    endTime?: number;

    /**
     * 搜索关键词
     */
    search?: string;

    /**
     * 标签列表
     */
    tags?: string[];

    /**
     * 只显示收藏
     */
    onlyFavorites?: boolean;

    /**
     * 分组ID
     */
    groupId?: string;
}