/**
 * 17. store/model-store.ts - 模型配置存储（改进）
 */
// packages/core/src/store/model-store.ts
import { createWithEqualityFn } from 'zustand/traditional';
import { persist } from 'zustand/middleware';
import { StandardModelType, ModelConfig, CustomInterface } from '../models/config';
import { defaultModelConfigs } from '../config/defaults';
import { STORAGE_KEYS } from '../config/constants';
import { generateId } from '../utils/id-generator';

// 模型类型（可以是标准类型或自定义接口ID）
export type ModelType = StandardModelType | string;

// Store状态接口
interface ModelState {
    // 当前选中的模型
    activeModel: ModelType;

    // 模型配置
    configs: Record<StandardModelType, ModelConfig>;

    // 自定义接口
    customInterfaces: CustomInterface[];

    // 设置当前活动模型
    setActiveModel: (model: ModelType) => void;

    // 获取当前活动模型配置
    getActiveModelConfig: () => ModelConfig | CustomInterface | null;

    // 更新标准模型配置
    updateConfig: (model: StandardModelType, config: Partial<ModelConfig>) => void;

    // 重置标准模型配置
    resetConfig: (model: StandardModelType) => void;

    // 自定义接口管理
    addCustomInterface: (customInterface: Omit<CustomInterface, 'id'>) => string;
    updateCustomInterface: (id: string, data: Partial<Omit<CustomInterface, 'id'>>) => void;
    deleteCustomInterface: (id: string) => void;

    // 判断是否为自定义接口
    isCustomInterface: (model: ModelType) => boolean;

    // 获取自定义接口
    getCustomInterface: (id: string) => CustomInterface | undefined;

    // 更新触发器
    lastUpdate: number;

    // 获取启用的模型列表
    getEnabledModels: () => Array<{ id: string, name: string }>;
}

// 创建store
export const useModelStore = createWithEqualityFn<ModelState>()(
    persist(
        (set, get) => ({
            activeModel: 'openai',
            configs: Object.entries(defaultModelConfigs).reduce((acc, [key, value]) => ({
                ...acc,
                [key]: {
                    ...value,
                    id: key
                }
            }), {} as Record<StandardModelType, ModelConfig>),
            customInterfaces: [],
            lastUpdate: Date.now(),

            setActiveModel: (model) => set(state => ({
                ...state,
                activeModel: model,
                lastUpdate: Date.now()
            })),

            getActiveModelConfig: () => {
                const { activeModel, configs, customInterfaces } = get();
                if (Object.keys(configs).includes(activeModel)) {
                    return {
                        ...configs[activeModel as StandardModelType],
                        id: activeModel
                    };
                }
                return customInterfaces.find(i => i.id === activeModel) || null;
            },

            updateConfig: (model, config) => set(state => ({
                ...state,
                configs: {
                    ...state.configs,
                    [model]: {
                        ...state.configs[model],
                        ...config,
                        id: model
                    }
                },
                lastUpdate: Date.now()
            })),

            resetConfig: (model) => set(state => ({
                ...state,
                configs: {
                    ...state.configs,
                    [model]: {
                        ...defaultModelConfigs[model],
                        id: model
                    }
                },
                lastUpdate: Date.now()
            })),

            addCustomInterface: (customInterface) => {
                const id = generateId();

                // 检查是否已存在相同的接口（通过 providerName 和 model）
                const existingInterface = get().customInterfaces.find(
                    item =>
                        item.providerName === customInterface.providerName &&
                        item.model === customInterface.model
                );

                if (existingInterface) {
                    // 如果已存在，直接返回现有接口的ID
                    return existingInterface.id;
                }

                set(state => ({
                    ...state,
                    customInterfaces: [
                        ...state.customInterfaces,
                        {
                            id,
                            ...customInterface
                        }
                    ],
                    lastUpdate: Date.now()
                }));
                return id;
            },

            // 以下是需要补充的方法
            updateCustomInterface: (id, data) => {
                set(state => ({
                    ...state,
                    customInterfaces: state.customInterfaces.map(item =>
                        item.id === id ? { ...item, ...data } : item
                    ),
                    lastUpdate: Date.now()
                }));
            },

            deleteCustomInterface: (id) => {
                set(state => {
                    const newState = {
                        ...state,
                        customInterfaces: state.customInterfaces.filter(item => item.id !== id),
                        lastUpdate: Date.now()
                    };

                    if (state.activeModel === id) {
                        newState.activeModel = 'openai';
                    }

                    return newState;
                });
            },

            isCustomInterface: (model) => {
                const standardTypes: string[] = Object.keys(defaultModelConfigs);
                return !standardTypes.includes(model);
            },

            getCustomInterface: (id) => {
                return get().customInterfaces.find(item => item.id === id);
            },

            getEnabledModels: () => {
                const { configs, customInterfaces } = get();
            
                const standardModels = Object.entries(configs)
                    .filter(([_, config]) => config.enabled !== false)
                    .map(([id, config]) => ({
                        id,
                        name: `${config.providerName} - ${config.model}`  // 修改这里，使用"provider-modelName"格式
                    }));
            
                const custom = customInterfaces
                    .filter(item => item.enabled !== false)
                    .map(item => ({
                        id: item.id,
                        name: `${item.providerName} - ${item.model}`  // 修改这里，使用"provider-modelName"格式
                    }));
            
                return [...standardModels, ...custom];
            }
        }),
        {
            name: STORAGE_KEYS.MODEL_STORE,
            partialize: (state) => ({
                ...state,
                lastUpdate: state.lastUpdate
            }),
            onRehydrateStorage: () => (state) => {
                if (state) {
                    state.lastUpdate = Date.now();
                }
            }
        }
    ),
    Object.is
);