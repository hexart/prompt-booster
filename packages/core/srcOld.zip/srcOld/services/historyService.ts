/**
 * 13. services/historyService.ts - 历史记录服务（新增）
 */
// packages/core/src/services/historyService.ts
import { HistoryItem, HistoryFilter } from '../models/history';
import { generateId } from '../utils/id-generator';

/**
 * 根据条件筛选历史记录
 * @param history 历史记录列表
 * @param filter 筛选条件
 * @returns 筛选后的历史记录
 */
export function filterHistory(
    history: HistoryItem[],
    filter: HistoryFilter = {}
): HistoryItem[] {
    let filteredHistory = [...history];
    
    // 按时间范围筛选
    if (filter.startTime !== undefined) {
        filteredHistory = filteredHistory.filter(item => item.timestamp >= (filter.startTime || 0));
    }
    
    if (filter.endTime !== undefined) {
        filteredHistory = filteredHistory.filter(item => item.timestamp <= (filter.endTime || Infinity));
    }
    
    // 按关键词搜索
    if (filter.search) {
        const searchLower = filter.search.toLowerCase();
        filteredHistory = filteredHistory.filter(item => 
            item.originalPrompt.toLowerCase().includes(searchLower) ||
            item.optimizedPrompt.toLowerCase().includes(searchLower) ||
            (item.reasoning && item.reasoning.toLowerCase().includes(searchLower))
        );
    }
    
    // 按标签筛选
    if (filter.tags && filter.tags.length > 0) {
        filteredHistory = filteredHistory.filter(item => 
            item.tags && filter.tags?.some(tag => item.tags?.includes(tag))
        );
    }
    
    // 按收藏筛选
    if (filter.onlyFavorites) {
        filteredHistory = filteredHistory.filter(item => item.favorite);
    }
    
    // 按分组筛选
    if (filter.groupId) {
        filteredHistory = filteredHistory.filter(item => item.groupId === filter.groupId);
    }
    
    return filteredHistory;
}

/**
 * 创建新的历史记录项
 * @param originalPrompt 原始提示词
 * @param optimizedPrompt 优化后的提示词
 * @param reasoning 优化理由
 * @param modelId 模型ID
 * @param version 版本号（新增）
 * @param groupId 组ID（新增）
 * @param iterationDirection 迭代方向（新增）
 * @returns 新的历史记录项
 */
export function createHistoryItem(
    originalPrompt: string,
    optimizedPrompt: string,
    reasoning?: string,
    modelId?: string,
    version: number = 1,
    groupId?: string,
    iterationDirection?: string
): HistoryItem {
    return {
        id: generateId(),
        timestamp: Date.now(),
        originalPrompt,
        optimizedPrompt,
        reasoning,
        modelId,
        tags: [],
        favorite: false,
        version, // 新增
        groupId: groupId || generateId(), // 新增，如果未提供则创建新组ID
        iterationDirection // 新增
    };
}

/**
 * 获取组内最大版本号（新增函数）
 * @param history 历史记录
 * @param groupId 组ID
 * @returns 最大版本号
 */
export function getMaxVersion(history: HistoryItem[], groupId: string): number {
    const versions = history
        .filter(item => item.groupId === groupId)
        .map(item => item.version);
    
    return versions.length > 0 ? Math.max(...versions) : 0;
}