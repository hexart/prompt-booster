/**
 * 14. services/index.ts - 导出所有服务（新增）
 */
// packages/core/src/services/index.ts
// 导出模板服务
export * from './templateService';

// 导出提示词服务
// export * from './promptService';

// 导出历史记录服务
export * from './historyService';

// 导出模型服务
export * from './modelService';

// 导出存储服务
export * from './storageService';